create PROCEDURE query_emp (
    p_id       IN    employees.employee_id%TYPE,
    p_name     OUT   employees.last_name%TYPE,
    p_salary   OUT   employees.salary%TYPE
) IS
BEGIN
    SELECT
        last_name, 
        salary
    INTO
        p_name,
        p_salary

    FROM
        employees
    WHERE
        employee_id = p_id;

END query_emp;

create or replace function get_sal
(p_id employees.employee_id%type) return number is
v_sal employees.salary%type :=0;

begin
 select salary
 into v_sal
 from employees
 where employee_id = p_id;
 return v_sal;
 end get_sal; /

