create view SALVU50 as
select employee_id ID_NUMBER, last_name NAME, salary * 12 ANN_SALARY
    from employees
    where department_id = 50
/

